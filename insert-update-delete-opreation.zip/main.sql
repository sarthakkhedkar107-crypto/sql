CREATE TABLE company_info (
    comp_id INT PRIMARY KEY,
    comp_name VARCHAR(45),
    address VARCHAR(100)
);

INSERT INTO company_info (comp_id, comp_name, address)
VALUES
    (1, 'Infosys', 'Pune'),
    (2, 'Tata', 'Pune'),
    (3, 'TCS', 'Mumbai'),
    (4,'pocso','thane');
SELECT * FROM company_info;

insert into company_info values(5,'Sk','Pune');
select * from company_info;

update company_info set comp_name='sarthak' where comp_id='5';
select * from company_info;

delete  from company_info where comp_id=3;
select * from company_info