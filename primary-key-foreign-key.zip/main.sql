create table dpt(dpt_id int primary key,
    name varchar(40),
    dept_name varchar(30),
    salary int);

create table emp(emp_id int primary key,
    name varchar(40),
    emp_name varchar(30),
    salary int,
    dpt_id int,
    foreign key(dpt_id)
      REFERENCES dpt(dpt_id));

insert into dpt (dpt_id,name,dept_name,salary)
values
    (1,'sarthak','softwere',40000),
(2,'sahil','IT',50000),
(3,'ram','hr',600000),
(4,'ved','manger',500000);

select * from dpt;
insert into emp (emp_id,name,emp_name,salary,dpt_id)
values
    (1,'sarthak','softwere',40000,1),
(2,'sahil','IT',50000,2),
(3,'ram','hr',600000,3),
(4,'ved','manger',500000,4);

select * from emp;






