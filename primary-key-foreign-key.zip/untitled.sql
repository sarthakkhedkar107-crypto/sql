insert into emp (emp_id,name,dept_name,salary)
values
    (1,'sarthak','softwere',40000),
(2,'sahil','IT',50000),
(3,'ram','hr',600000),
(4,'ved','manger',500000);
