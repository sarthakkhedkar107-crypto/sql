

-- Department Table
CREATE TABLE department (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50)
);

-- Employee Table
CREATE TABLE employee (
    emp_id INT PRIMARY KEY,
    emp_name VARCHAR(50),
    emp_salary DECIMAL(10,2),
    dept_id INT,

    FOREIGN KEY (dept_id)
    REFERENCES department(dept_id)
);

-- Insert records into Department
INSERT INTO department (dept_id, dept_name)
VALUES
(1, 'HR'),
(2, 'IT'),
(3, 'Finance');

-- Insert records into Employee
INSERT INTO employee (emp_id, emp_name, emp_salary, dept_id)
VALUES
(101, 'Sarthak', 50000, 2),
(102, 'Rahul', 45000, 1),
(103, 'Amit', 55000, 3);

-- Display Employee with Department Name
SELECT employee.emp_id, employee.emp_name,
       employee.emp_salary, department.dept_name
FROM employee
JOIN department
ON employee.dept_id = department.dept_id;